int square(int i) {
  return i*i;
}
