#include <iostream>

int lib_hello() {
  std::cout << "LIB: Hello World!\n";
  return 0;
}
